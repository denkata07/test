#!/bin/sh

command -v java >/dev/null 2>&1 || {
	echo "This program needs Java 1.6. Please make sure the java binary is in the path.";
	echo "e.g.: export PATH=\"<java-install-dir>/bin:\${PATH}\"";
	exit 1;
}

# On Unix systems the setjmsenv and setjmsenv64 scripts set MQ_JAVA_LIB_PATH and CLASSPATH
if [ -z "${MQ_JAVA_LIB_PATH}" ]; then
	echo "The MQ_JAVA_LIB_PATH environment variable is not set. Please execute"
	echo "source <mq-install-path>/java/bin/setjmsenv"
	echo "or"
	echo "source <mq-install-path>/java/bin/setjmsenv64"
	echo "before starting this script."
	exit 1
fi

cd "$( dirname "$0" )"

java -cp "${CLASSPATH}:createmqmappings.jar" -Djava.library.path="${MQ_JAVA_LIB_PATH}" com.dynatrace.createmqmappings.CreateMQMappings $@
